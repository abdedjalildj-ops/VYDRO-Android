# VYDRO Android

Native Android Studio wrapper for the VYDRO Arabic RTL storefront prototype. The storefront is bundled in `app/src/main/assets` and runs locally in an Android WebView.

See `README_AR.txt` for APK build instructions and prototype limitations.
