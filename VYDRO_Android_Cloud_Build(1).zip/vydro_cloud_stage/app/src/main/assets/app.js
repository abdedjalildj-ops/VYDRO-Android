const products = [
  {id:1,name:"موزّع الحبوب والبقوليات — 4 أقسام",desc:"يساعد على ترتيب الحبوب والبقوليات وسهولة الوصول إليها في المطبخ.",icon:"▤",tag:"تنظيم المطبخ"},
  {id:2,name:"منظّم البيض",desc:"حل عملي لترتيب البيض داخل الثلاجة والاستفادة من المساحة.",icon:"◉",tag:"ترتيب الثلاجة"},
  {id:3,name:"علب حفظ الطعام",desc:"لترتيب المواد الغذائية وحفظها بطريقة أكثر تنظيماً.",icon:"▣",tag:"حفظ الطعام"}
];
const $ = s => document.querySelector(s);
let cart = [];
try { cart = JSON.parse(localStorage.getItem('vydro-cart') || '[]'); if (!Array.isArray(cart)) cart = []; } catch { cart = []; }
function saveCart(){ try { localStorage.setItem('vydro-cart', JSON.stringify(cart)); } catch {} }
function renderProducts(){
  $("#productGrid").innerHTML = products.map(p => `<article class="product"><div class="product-art"><span class="tag">${p.tag}</span><div class="shape">${p.icon}</div></div><div class="product-info"><h3>${p.name}</h3><p>${p.desc}</p><span class="price">السعر يحدد بعد تأكيد المورد</span><button data-add="${p.id}">أضف إلى السلة</button></div></article>`).join('');
}
function renderCart(){
  $('#cartCount').textContent = cart.reduce((sum,item)=>sum+item.qty,0);
  $('#cartItems').innerHTML = cart.length ? cart.map(item=>`<div class="cart-row"><span>${item.name} × ${item.qty}</span><button data-remove="${item.id}">حذف</button></div>`).join('') : '<p class="empty">السلة فارغة حالياً.</p>';
  $('#total').textContent = 'يحدد لاحقاً';
  saveCart();
}
function add(id){const p=products.find(x=>x.id===id); if(!p)return; const old=cart.find(x=>x.id===id); old?old.qty++:cart.push({...p,qty:1}); renderCart();}
$('#productGrid').addEventListener('click',e=>{const b=e.target.closest('[data-add]');if(b)add(Number(b.dataset.add));});
$('#cartItems').addEventListener('click',e=>{const b=e.target.closest('[data-remove]');if(b){cart=cart.filter(x=>x.id!==Number(b.dataset.remove));renderCart();}});
$('#addBundle').onclick=()=>{products.forEach(p=>{const old=cart.find(x=>x.id===p.id);old?old.qty++:cart.push({...p,qty:1});});renderCart();openCart();};
function openCart(){$('#cartDrawer').classList.add('open');$('#backdrop').classList.add('show');}
function closeCart(){$('#cartDrawer').classList.remove('open');$('#backdrop').classList.remove('show');}
$('#openCart').onclick=openCart;$('#closeCart').onclick=closeCart;$('#backdrop').onclick=closeCart;
$('#checkoutBtn').onclick=()=>{if(!cart.length)return;closeCart();$('#checkoutModal').classList.add('show');$('#orderResult').hidden=true;};
$('#closeModal').onclick=()=>$('#checkoutModal').classList.remove('show');
$('#checkoutModal').addEventListener('click',e=>{if(e.target.id==='checkoutModal')$('#checkoutModal').classList.remove('show');});
$('#orderForm').onsubmit=e=>{e.preventDefault();const data=new FormData(e.target);const summary=cart.map(x=>`${x.name} (${x.qty})`).join('، ');$('#orderResult').hidden=false;$('#orderResult').textContent=`معاينة تجريبية فقط — ${data.get('name')}، ${data.get('phone')}، ${data.get('address')}. المنتجات: ${summary}. لم يتم إرسال الطلب أو حفظ البيانات.`;};
let installPrompt;
window.addEventListener('beforeinstallprompt',event=>{event.preventDefault();installPrompt=event;$('#installApp').hidden=false;});
$('#installApp').addEventListener('click',async()=>{if(!installPrompt)return;installPrompt.prompt();await installPrompt.userChoice;installPrompt=null;$('#installApp').hidden=true;});
window.addEventListener('appinstalled',()=>{$('#installApp').hidden=true;});
renderProducts();renderCart();
if('serviceWorker' in navigator){window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(()=>{}));}
